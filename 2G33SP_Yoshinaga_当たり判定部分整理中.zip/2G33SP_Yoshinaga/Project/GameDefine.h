#pragma once	
#include "Mof.h"

#define		GRAVITY		0.7f

enum SCENENO
{
	SCENENO_TITLE,
	SCENENO_GAME,
	SCENENO_GAMEOVER,
	SCENENO_GAMECLEAR,
};
	


